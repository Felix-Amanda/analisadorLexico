mvn package
java -cp target/jackcompiler-1.0-SNAPSHOT.jar br.ufma.ecp.App